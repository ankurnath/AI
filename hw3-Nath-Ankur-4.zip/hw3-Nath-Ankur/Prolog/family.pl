% males
male(charles).
male(william).
male(george).
male(louis).
male(harry).
male(archie).



% females
female(camila).
female(diana).
female(catherine).
female(charlotte).
female(meghan).



% spouse
spouse(charles,camila).
spouse(camila,charles).

spouse(charles,diana).
spouse(diana,charles).

spouse(william,catherine).
spouse(catherine,william).

spouse(harry,meghan).
spouse(meghan,harry).



% parent
parent(charles,william).
parent(diana,william).

parent(charles,harry).
parent(diana,harry).

parent(william,george).
parent(catherine,george).

parent(william,charlotte).
parent(catherine,charlotte).


parent(william,louis).
parent(catherine,louis).

parent(harry,archie).
parent(meghan,archie).



mother(X,Y):- parent(X,Y),female(X).
father(X,Y):- parent(X,Y),male(X).




brother(X,Y):- mother(Z,X),mother(Z,Y),father(F,X),father(F,Y),male(X),X\==Y.
sister(X,Y):- mother(Z,X),mother(Z,Y),father(F,X),father(F,Y),female(X),X\==Y.

sister_in_law(X,Y) :-brother(Z,Y),spouse(X,Z).

siblings(X,Y):- mother(M,X),mother(M,Y),father(F,X),father(F,Y),X\==Y.

nephew(X,Y):-siblings(Z,Y),parent(Z,X),male(X).
niece(X,Y):-siblings(Z,Y),parent(Z,X),female(X).

grandparent(X,Y):-parent(Z,Y),parent(X,Z).


stepmother(X,Y):- father(Z,Y),spouse(X,Z),not(mother(X,Y)).

cousin(X,Y) :- parent(Z,Y),siblings(S,Z),parent(S,X).
female_cousin(X,Y) :- cousin(X,Y),female(X).


uncle(X,Y):-parent(Z,Y),(brother(X,Z) ; sister(S,Z),spouse(X,S)).
aunt(X,Y):-parent(Z,Y),(sister(X,Z) ; brother(B,Z),spouse(X,B)).

/*
grandparent(charles,Grandchildren).
sister_in_law(SisterInLaw,william).
uncle(Uncle,charlotte).
aunt(Aunt,archie).
nephew(Nephew,harry).
stepmother(Stepmother,william).
siblings(Person1,Person2).
female_cousin(_,Person).
niece(_,Uncle). 


*/












